klynt.miniPlayerData = {
    "fullscreenInfoWording": "This program will launch in fullscreen",
    "launchAppWording": "Then Launch Project",
    "title": "ARG_CEO",
    "thanksForWatchingWording": "Thanks for watching!",
    "description": "",
    "resumePlaybackWording": "Resume playback?",
    "redirectToMobileApp": "always",
    "yesWording": "Yes",
    "url": "",
    "noWording": "No",
    "thumbnail": "Player/css/editor/img/mini-player.jpg",
    "analyticsKey": "",
    "downloadAppWording": "Download App"
}